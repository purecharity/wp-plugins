# ChangeLog

* (5 November 2014). Added Base Plugin dependency.
* (22 May 2019). Removed the text "all kids" from the "Back to All Kids" button
* (28 June 2019). Adjusted padding of Option 1 view
* (17 June 2020) Modiified code to allow the 13+ age filter to work properly
