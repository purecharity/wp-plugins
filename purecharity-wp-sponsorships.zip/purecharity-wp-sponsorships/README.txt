=== Pure Charity Sponsorships ===
Contributors: rafaeldalpra
Donate link: http://purecharity.com/
Tags: purecharity, sponsorships
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to list and show details about sponsorship programs in your wordpress site.

== Description ==

A plugin to list and show details about sponsorship programs in your wordpress site.

== Installation ==

1. Upload the `purecharity-wp-sponsorships/trunk` folder contents to the `/wp-content/plugins/purecharity-wp-sponsorships` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You're done!

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.5 =
* Back and More link on layout 3 are now customizable

= 1.4.5 =
* Added status filter to shortcode and template tag

= 1.4.4 =
* Added limit to sponsorships template tag

= 1.4.3 =
* Bugfix

= 1.4.2 =
* Hiding paragraph when there's no description

= 1.4.1 =
* Added age display

= 1.4 =
* Added new about optional field

= 1.3.1 =
* Parameter name change

= 1.3 =
* Added template tags  

= 1.2 =
* Added custom template option

= 1.1.7 =
* Performance improvement

= 1.1.6 =
* Bugfix with the total slots available

= 1.1.5 =
* Minor adjustments to hide bullets when only one sponsorship is available.

= 1.1.4 =
* Single page improvements.

= 1.1.3 =
* Added exclusion filter to the shortcode.

= 1.1.2 =
* Change the way it shows when there is only one sponsorship slot available, improve mobile styles.

= 1.1.1 =
* Added text search.

= 1.1 =
* Added alternative rounded layout.

= 1.0.6 =
* Updated the sponsorships goal calculation.

= 1.0.4 =
* Removed obsolete shortcode.

= 1.0.3 =
* Added the GitHub updater process.

= 1.0.2 =
* Added the option to hide the powered by Pure Charity image.

= 1.0.1 =
* Added the option to force a template use for the single view.

= 1.0 =
* First plugin version.

== Upgrade Notice ==

= 1.0 =
Nothing to add yet.
